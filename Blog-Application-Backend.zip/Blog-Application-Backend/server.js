require("dotenv").config();
const express=require("express"), cors=require("cors"), bcrypt=require("bcryptjs"), jwt=require("jsonwebtoken"), fs=require("fs"), path=require("path");
const app=express(), PORT=process.env.PORT||3000, SECRET=process.env.JWT_SECRET;
if(!SECRET){console.error("Create .env from .env.example and set JWT_SECRET");process.exit(1);}
app.use(cors()); app.use(express.json()); app.use(express.static(path.join(__dirname,"public")));
const file=path.join(__dirname,"data.json");
function db(){if(!fs.existsSync(file))fs.writeFileSync(file,JSON.stringify({users:[],blogs:[]}));return JSON.parse(fs.readFileSync(file));}
function save(d){fs.writeFileSync(file,JSON.stringify(d,null,2));}
function auth(req,res,next){const t=(req.headers.authorization||"").replace(/^Bearer /,"");try{if(!t)throw Error();req.user=jwt.verify(t,SECRET);next();}catch{return res.status(401).json({message:"Please log in."});}}
function token(u){return jwt.sign({id:u.id,email:u.email},SECRET,{expiresIn:"2h"});}
app.get("/api/health",(req,res)=>res.json({message:"BlogSpace API is running"}));
app.post("/api/auth/register",async(req,res)=>{try{const{name,email,password}=req.body;if(!name||!email||!password)return res.status(400).json({message:"All fields are required"});if(password.length<6)return res.status(400).json({message:"Password must be at least 6 characters"});const d=db(),e=email.trim().toLowerCase();if(d.users.some(u=>u.email===e))return res.status(409).json({message:"Email already registered"});const u={id:Date.now().toString(),name:name.trim(),email:e,passwordHash:await bcrypt.hash(password,10)};d.users.push(u);save(d);res.status(201).json({message:"Registered",token:token(u),user:{id:u.id,name:u.name,email:u.email}});}catch{res.status(500).json({message:"Server error"});}});
app.post("/api/auth/login",async(req,res)=>{const{email,password}=req.body;const u=db().users.find(x=>x.email===String(email||"").trim().toLowerCase());if(!u||!(await bcrypt.compare(password||"",u.passwordHash)))return res.status(401).json({message:"Invalid email or password"});res.json({message:"Login successful",token:token(u),user:{id:u.id,name:u.name,email:u.email}});});
app.get("/api/blogs",(req,res)=>res.json(db().blogs.sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt))));
app.post("/api/blogs",auth,(req,res)=>{const{title,category,content}=req.body;if(!title||!category||!content)return res.status(400).json({message:"All blog fields are required"});const d=db(),u=d.users.find(x=>x.id===req.user.id),b={id:Date.now().toString(),title,category,content,author:u.name,authorId:u.id,createdAt:new Date().toISOString()};d.blogs.push(b);save(d);res.status(201).json({message:"Blog created",blog:b});});
app.get("/api/blogs/mine",auth,(req,res)=>res.json(db().blogs.filter(b=>b.authorId===req.user.id)));
app.delete("/api/blogs/:id",auth,(req,res)=>{const d=db(),b=d.blogs.find(x=>x.id===req.params.id);if(!b)return res.status(404).json({message:"Blog not found"});if(b.authorId!==req.user.id)return res.status(403).json({message:"Not your blog"});d.blogs=d.blogs.filter(x=>x.id!==b.id);save(d);res.json({message:"Blog deleted"});});
app.listen(PORT,()=>console.log(`BlogSpace running at http://localhost:${PORT}`));
