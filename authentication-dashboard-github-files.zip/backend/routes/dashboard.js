const express = require("express");
const User = require("../models/User");
const Blog = require("../models/Blog");
const authMiddleware = require("../middleware/auth");

const router = express.Router();

// All dashboard routes below require a valid JWT.
router.use(authMiddleware);

// GET /api/dashboard/profile
router.get("/profile", async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select("-password");
    if (!user) return res.status(404).json({ message: "User not found." });

    res.json({
      id: user._id,
      name: user.name,
      email: user.email
    });
  } catch (error) {
    res.status(500).json({ message: "Could not load profile." });
  }
});

// GET /api/dashboard/my-blogs
router.get("/my-blogs", async (req, res) => {
  try {
    // This assumes Blog.author stores the User document ID.
    const blogs = await Blog.find({ author: req.user.id }).sort({ createdAt: -1 });
    res.json(blogs);
  } catch (error) {
    res.status(500).json({ message: "Could not load your blogs." });
  }
});

module.exports = router;
