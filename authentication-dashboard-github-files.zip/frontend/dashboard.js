// Change this URL if your backend runs on another host or port.
const API_BASE = "http://localhost:5000/api";
const token = localStorage.getItem("token");

if (!token) {
  window.location.href = "login.html";
}

async function loadDashboard() {
  try {
    const headers = { Authorization: `Bearer ${token}` };

    const profileResponse = await fetch(`${API_BASE}/dashboard/profile`, { headers });
    if (profileResponse.status === 401) {
      localStorage.removeItem("token");
      window.location.href = "login.html";
      return;
    }
    if (!profileResponse.ok) throw new Error("Unable to load profile.");

    const profile = await profileResponse.json();
    document.getElementById("userName").textContent = profile.name || "";
    document.getElementById("userEmail").textContent = profile.email || "";

    const blogsResponse = await fetch(`${API_BASE}/dashboard/my-blogs`, { headers });
    if (!blogsResponse.ok) throw new Error("Unable to load blogs.");

    const blogs = await blogsResponse.json();
    const blogsContainer = document.getElementById("myBlogs");
    blogsContainer.replaceChildren();

    if (!blogs.length) {
      blogsContainer.textContent = "You have not created any blogs yet.";
      return;
    }

    blogs.forEach((blog) => {
      const article = document.createElement("article");
      const heading = document.createElement("h3");
      const paragraph = document.createElement("p");

      heading.textContent = blog.title || "Untitled blog";
      paragraph.textContent = blog.content || blog.description || "";

      article.append(heading, paragraph);
      blogsContainer.appendChild(article);
    });
  } catch (error) {
    document.getElementById("myBlogs").textContent = error.message;
  }
}

document.getElementById("logoutBtn").addEventListener("click", () => {
  localStorage.removeItem("token");
  window.location.href = "login.html";
});

loadDashboard();
