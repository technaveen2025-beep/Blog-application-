// Add this logic to your existing login form handler.
// Your login form should have inputs with IDs: email and password.
const API_BASE = "http://localhost:5000/api";

async function loginUser(event) {
  event.preventDefault();

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  try {
    const response = await fetch(`${API_BASE}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });

    const data = await response.json();
    if (!response.ok) {
      alert(data.message || "Login failed.");
      return;
    }

    localStorage.setItem("token", data.token);
    window.location.href = "dashboard.html";
  } catch (error) {
    alert("Cannot connect to the server. Please try again.");
  }
}

// Example: document.getElementById("loginForm").addEventListener("submit", loginUser);
