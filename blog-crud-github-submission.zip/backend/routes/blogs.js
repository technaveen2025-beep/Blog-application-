const express = require("express");
const mongoose = require("mongoose");
const Blog = require("../models/Blog");
const jwt = require("jsonwebtoken");

const router = express.Router();

// Require a valid login token for creating, updating, and deleting blogs.
function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ message: "Login required" });
  }

  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ message: "Invalid or expired token" });
  }
}

// CREATE: POST /api/blogs
router.post("/", auth, async (req, res) => {
  try {
    const { title, content, category } = req.body;

    if (typeof title !== "string" || !title.trim() ||
        typeof content !== "string" || !content.trim()) {
      return res.status(400).json({
        message: "A title and content are required"
      });
    }

    const blog = await Blog.create({
      title: title.trim(),
      content: content.trim(),
      category: typeof category === "string" && category.trim()
        ? category.trim()
        : "General",
      author: req.user.id
    });

    return res.status(201).json({
      message: "Blog created successfully",
      blog
    });
  } catch (error) {
    console.error("Create blog error:", error.message);
    return res.status(500).json({ message: "Could not create blog" });
  }
});

// READ: GET /api/blogs?search=...&category=...
router.get("/", async (req, res) => {
  try {
    const { search, category } = req.query;
    const filter = {};

    if (typeof search === "string" && search.trim()) {
      const escaped = search.trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      filter.$or = [
        { title: { $regex: escaped, $options: "i" } },
        { content: { $regex: escaped, $options: "i" } }
      ];
    }

    if (typeof category === "string" && category.trim()) {
      filter.category = category.trim();
    }

    const blogs = await Blog.find(filter)
      .populate("author", "name")
      .sort({ createdAt: -1 });

    return res.json(blogs);
  } catch (error) {
    console.error("Get blogs error:", error.message);
    return res.status(500).json({ message: "Could not retrieve blogs" });
  }
});

// READ ONE: GET /api/blogs/:id
router.get("/:id", async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: "Invalid blog ID" });
    }

    const blog = await Blog.findById(req.params.id)
      .populate("author", "name");

    if (!blog) {
      return res.status(404).json({ message: "Blog not found" });
    }

    return res.json(blog);
  } catch (error) {
    console.error("Get blog error:", error.message);
    return res.status(500).json({ message: "Could not retrieve blog" });
  }
});

// UPDATE: PUT /api/blogs/:id (only the author can update)
router.put("/:id", auth, async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: "Invalid blog ID" });
    }

    const blog = await Blog.findById(req.params.id);

    if (!blog) {
      return res.status(404).json({ message: "Blog not found" });
    }

    if (String(blog.author) !== String(req.user.id)) {
      return res.status(403).json({ message: "You cannot edit this blog" });
    }

    const { title, content, category } = req.body;

    if (title !== undefined) {
      if (typeof title !== "string" || !title.trim()) {
        return res.status(400).json({ message: "Title cannot be empty" });
      }
      blog.title = title.trim();
    }

    if (content !== undefined) {
      if (typeof content !== "string" || !content.trim()) {
        return res.status(400).json({ message: "Content cannot be empty" });
      }
      blog.content = content.trim();
    }

    if (category !== undefined) {
      if (typeof category !== "string" || !category.trim()) {
        return res.status(400).json({ message: "Category cannot be empty" });
      }
      blog.category = category.trim();
    }

    await blog.save();

    return res.json({ message: "Blog updated successfully", blog });
  } catch (error) {
    console.error("Update blog error:", error.message);
    return res.status(500).json({ message: "Could not update blog" });
  }
});

// DELETE: DELETE /api/blogs/:id (only the author can delete)
router.delete("/:id", auth, async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: "Invalid blog ID" });
    }

    const blog = await Blog.findById(req.params.id);

    if (!blog) {
      return res.status(404).json({ message: "Blog not found" });
    }

    if (String(blog.author) !== String(req.user.id)) {
      return res.status(403).json({ message: "You cannot delete this blog" });
    }

    await blog.deleteOne();

    return res.json({ message: "Blog deleted successfully" });
  } catch (error) {
    console.error("Delete blog error:", error.message);
    return res.status(500).json({ message: "Could not delete blog" });
  }
});

module.exports = router;
