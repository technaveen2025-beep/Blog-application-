// Blog CRUD helpers for the browser.
// Include this file in your page with: <script src="crud.js"></script>
// Login code must save the JWT returned by the backend as localStorage key "token".

const BLOG_API = "http://localhost:5000/api/blogs";

function getAuthHeaders() {
  const token = localStorage.getItem("token");
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function parseApiResponse(response) {
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.message || `Request failed (${response.status})`);
  }
  return data;
}

// CREATE
async function createBlog(title, content, category = "General") {
  const response = await fetch(BLOG_API, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...getAuthHeaders()
    },
    body: JSON.stringify({ title, content, category })
  });
  return parseApiResponse(response);
}

// READ ALL, optionally with search/category filters
async function getBlogs(search = "", category = "") {
  const params = new URLSearchParams();
  if (search.trim()) params.set("search", search.trim());
  if (category.trim()) params.set("category", category.trim());

  const query = params.toString();
  const response = await fetch(`${BLOG_API}${query ? `?${query}` : ""}`);
  return parseApiResponse(response);
}

// READ ONE
async function getBlogById(id) {
  const response = await fetch(`${BLOG_API}/${encodeURIComponent(id)}`);
  return parseApiResponse(response);
}

// UPDATE
async function updateBlog(id, title, content, category = "General") {
  const response = await fetch(`${BLOG_API}/${encodeURIComponent(id)}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      ...getAuthHeaders()
    },
    body: JSON.stringify({ title, content, category })
  });
  return parseApiResponse(response);
}

// DELETE
async function deleteBlog(id) {
  const response = await fetch(`${BLOG_API}/${encodeURIComponent(id)}`, {
    method: "DELETE",
    headers: getAuthHeaders()
  });
  return parseApiResponse(response);
}
